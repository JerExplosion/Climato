//
//  XJViewController.swift
//  FireStyleFireBaseJutsu
//
//  Created by Jerry Ren on 7/29/20.
//  Copyright © 2020 Jerry Ren. All rights reserved.
//

// xj = 细节
import UIKit

protocol NotificPacific {
    
                        }
class XJViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

}
